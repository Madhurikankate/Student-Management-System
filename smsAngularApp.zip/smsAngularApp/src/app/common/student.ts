export class Student {

    id : number;
    name : String;
    phone : String;
    address : String;
    Grade : String;
    createdDate : Date;
    lastUpdatedDate : Date;
    grade : String;
    gender : String;
}
