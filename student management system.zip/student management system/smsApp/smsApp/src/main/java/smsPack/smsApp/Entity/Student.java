package smsPack.smsApp.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "studentCRUD")

public class Student {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Integer studentId;

	@NotEmpty
	@Size(min = 3, message = "firstName must contain atleast 3 characters")
	private String studentName;

	@Column(name = "email_id", unique = true, length = 30)
	@NotEmpty
	@Email(message = "Email is not valid!")
	public String emailId;

	@NotEmpty
	@Size(min = 8, message = "Password length must be 8 and contain uppercase,lowercase,digits")
	// @Pattern(regexp="(?=.*\\d)(?=.*[a-z])(?=.*[A-Z]).{8,}")
	private String studentPassword;

	@NotEmpty
	@Size(min = 10, max = 10, message = "phoneNumber must contain 10 digits")
	private String studentContactNumber;

	@NotEmpty(message = "Address can not be empty")
	private String studentAddress;

	@NotEmpty(message = "Gender can not be empty")
	private String studentGender;

	@NotEmpty(message = "Skills can not be empty")
	private String studentSkills;

	public Student() {
		super();
	}

	public Student (Integer studentUId,
			@NotEmpty @Size(min = 3, message = "firstName must contain atleast 3 characters") String employeeName,
			@NotEmpty @Email(message = "Email is not valid!") String emailId,
			@NotEmpty @Size(min = 8, message = "Password length must be 8 and contain uppercase,lowercase,digits") String employeePassword,
			@NotEmpty @Size(min = 10, max = 10, message = "phoneNumber must contain 10 digits") String employeeContactNumber,
			@NotEmpty(message = "Address can not be empty") String employeeAddress,
			@NotEmpty(message = "Gender can not be empty") String employeeGender,
			@NotEmpty(message = "Skills can not be empty") String employeeSkills) {
		super();
		this.studentId = studentId;
		this.studentName = studentName;
		this.studentId = studentId;
		this.studentPassword = studentPassword;
		this.studentContactNumber = studentContactNumber;
		this.studentAddress = studentAddress;
		this.studentGender = studentGender;
		this.studentSkills = studentSkills;
	}

	public Integer getStudentId() {
		return studentId;
	}

	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getStudentPassword() {
		return studentPassword;
	}

	public void setStudentPassword(String studentPassword) {
		this.studentPassword = studentPassword;
	}

	public String getStudentContactNumber() {
		return studentContactNumber;
	}

	public void setStudentContactNumber(String studentContactNumber) {
		this.studentContactNumber = studentContactNumber;
	}

	public String getStudentAddress() {
		return studentAddress;
	}

	public void setStudentAddress(String studentAddress) {
		this.studentAddress = studentAddress;
	}

	public String getStudentGender() {
		return studentGender;
	}

	public void setStudentGender(String studentGender) {
		this.studentGender = studentGender;
	}

	public String getStudentSkills() {
		return studentSkills;
	}

	public void setStudentSkills(String studentSkills) {
		this.studentSkills = studentSkills;
	}

	

}
