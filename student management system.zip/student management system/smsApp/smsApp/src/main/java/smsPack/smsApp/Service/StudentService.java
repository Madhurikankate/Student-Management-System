package smsPack.smsApp.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.SortedMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


import smsPack.smsApp.Dao.StudentDao;
import smsPack.smsApp.Entity.Student;

@Service
public class StudentService {
	@Autowired
	private StudentDao studentDao;
	
	//Save or create new record
	public Student saveStudent(Student student)
	{
		return studentDao.save(student);
	}
	
	//Retrieve all the record
	public List<Student> getStudents()
	{
		List<Student> students = new ArrayList<>();
		studentDao.findAll().forEach(students::add);
		return students;
	}
	
	//Retrieve single record
	public Student getStudentss(Integer studentId)
	{
		return studentDao.findById((studentId)).orElseThrow();
	}
	
	//delete single record
	public void deleteStudent(Integer studentId)
	{
		studentDao.deleteById(studentId);
	}
	
	//Update existing record
	public Student updateStudent(Student student)
	{
		studentDao.findById(student.getStudentId()).orElseThrow();
		return studentDao.save(student);
	}
	
	// Search employee by name
	public Student getStudentByName(String studentName) {
	return  studentDao.findByStudentName(studentName)
	.orElseThrow(() -> new RuntimeException("Student not found with name: " +studentName));
	}
	
	//Method to get employees sorted by name
	public List<Student> getStudentSortedByName()
	{
		//return studentDao.findAll(Sort.by(Sort.Direction. ASC,"studentName"));
		return studentDao.findAll(Sort.by(Sort.Direction.ASC,"studentName"));
	}
	
	//Method to handle login
    public Student login(String emailId, String studentPassword) {
        return studentDao.findByEmailIdAndStudentPassword(emailId, studentPassword)
                .orElseThrow(() -> new RuntimeException("Invalid email or password!"));
    }

}
