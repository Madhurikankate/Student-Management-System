package smsPack.smsApp.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import EmsPack.EmsProject.DTO.LoginRequest;
import EmsPack.EmsProject.Entity.Employee;
import smsPack.smsApp.Entity.Student;
import smsPack.smsApp.Service.StudentService;

@RestController
@CrossOrigin("http://localhost:4200")
public class StudentController 
{
	@Autowired
	private StudentService studentService;

	@PostMapping("/save/student")
	public Student saveStudent(@RequestBody Student student) {
		return studentService.saveStudent(student);
	}

	@GetMapping("/get/student")
	public List<Student> getStudent() {
		return studentService.getStudents();
	}

	@GetMapping("/get/student/{studentId}")
	public Student getStudent(@PathVariable Integer studentId) {
		return studentService.getStudentss(studentId);
	}

	@DeleteMapping("/delete/student/{studentId}")
	public void deleteStudent(@PathVariable Integer studentId) {
		studentService.deleteStudent(studentId);
	}

	@PutMapping("/update/student")
	public ResponseEntity<Student> updateStudent(@RequestBody Student student) {
		Student updatedStudent = studentService.updateStudent(student);
		if (updatedStudent != null) {
			return ResponseEntity.ok(updatedStudent);
		} else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		}
	}

	/*
	 * @PutMapping("/update/employee") public Employee updateEmployee(@RequestBody
	 * Employee employee) { return employeeService.updateEmployee(employee); }
	 */

	// Endpoint to get employee by name
	@GetMapping("/name/{studentName}")
	public ResponseEntity<Student> getStudentByName(@PathVariable String studentName) {
		Student student = studentService.getStudentByName(studentName);
		return ResponseEntity.ok(student);
	}

	// Endpoint to get employees sorted by name
	@GetMapping("/sorted-by-name")
	public ResponseEntity<List<Student>> getStudentsSortedByName() {
		List<Student> sortedStudents = studentService.getStudentSortedByName();
		return ResponseEntity.ok(sortedStudents);
	}

	// Endpoint for login
	@PostMapping("/login")
	public ResponseEntity<String> login(@RequestBody LoginRequest loginRequest) {
		try {
			Student student = studentService.login(loginRequest.getEmailId(), loginRequest.getStudentPassword());
			return ResponseEntity.ok("Welcome, " + student.getStudentName() + "!");
		} catch (RuntimeException e) {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(e.getMessage());
		}
	}

}
