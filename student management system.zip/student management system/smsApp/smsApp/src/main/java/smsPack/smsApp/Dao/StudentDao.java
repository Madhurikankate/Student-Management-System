package smsPack.smsApp.Dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import smsPack.smsApp.Entity.Student;

@Repository
public interface StudentDao extends JpaRepository<Student, Integer>
{
	//Method to find employee by email and  password
		Optional<Student> findByEmailIdAndStudentPassword(String emailId, String studentPassword);
		
		//Method to find employee by name
		Optional<Student> findByStudentName(String studentName);
		
		// Method to find all employees and sort by name
		List<Student> findAll(Sort sort);
}
